# FastAPI Gym Management System

## Project Description
This is a backend Gym Management System built using FastAPI as part of the FastAPI Internship Final Project.

The project includes:
- CRUD Operations
- Pydantic Validation
- Search API
- Sorting API
- Pagination API
- Multi-step Workflow APIs
- Swagger UI Testing

---

## Features Implemented

### Member Management
- Create Member
- Get All Members
- Get Member By ID
- Update Member
- Delete Member

### Advanced APIs
- Search Members
- Sort Members
- Pagination
- Filter Members by Plan

### Workflow APIs
- Assign Trainer
- Activate Membership

### Summary API
- Total Members
- Total Trainers

---

## Technologies Used
- Python
- FastAPI
- Uvicorn
- Pydantic
- Ngrok

---

## API Testing
All APIs were tested using Swagger UI.

Swagger Endpoint:
```bash
/docs
```

---

## Run Project

Install dependencies:

```bash
pip install -r requirements.txt
```

Run server:

```bash
uvicorn main:app --reload
```

---

## Project Structure

```bash
├── main.py
├── requirements.txt
├── README.md
└── screenshots/
```

---

## Author
Ravi Mohan